DROP TABLE IF EXISTS TimeTest;
CREATE TABLE TimeTest([Key] VARCHAR(20), [Value] DATETIME2);
GO
DROP TABLE IF EXISTS t;
create table t ( nr int, nazwa varchar(30) );
GO
INSERT INTO TimeTest VALUES('StartTime',GETDATE());
GO
insert t values( 1, 'Testowanie57' )
go
insert t values( 2, 'Testowanie47' )
go
insert t values( 3, 'Testowanie28' )
go
insert t values( 4, 'Testowanie38' )
go
insert t values( 5, 'Testowanie14' )
go
insert t values( 6, 'Testowanie97' )
go
insert t values( 7, 'Testowanie9' )
go
insert t values( 8, 'Testowanie40' )
go
insert t values( 9, 'Testowanie53' )
go
insert t values( 10, 'Testowanie86' )
go
insert t values( 11, 'Testowanie82' )
go
insert t values( 12, 'Testowanie85' )
go
insert t values( 13, 'Testowanie66' )
go
insert t values( 14, 'Testowanie44' )
go
insert t values( 15, 'Testowanie93' )
go
insert t values( 16, 'Testowanie11' )
go
insert t values( 17, 'Testowanie74' )
go
insert t values( 18, 'Testowanie1' )
go
insert t values( 19, 'Testowanie72' )
go
insert t values( 20, 'Testowanie65' )
go
insert t values( 21, 'Testowanie78' )
go
insert t values( 22, 'Testowanie76' )
go
insert t values( 23, 'Testowanie74' )
go
insert t values( 24, 'Testowanie70' )
go
insert t values( 25, 'Testowanie19' )
go
insert t values( 26, 'Testowanie63' )
go
insert t values( 27, 'Testowanie84' )
go
insert t values( 28, 'Testowanie27' )
go
insert t values( 29, 'Testowanie46' )
go
insert t values( 30, 'Testowanie18' )
go
insert t values( 31, 'Testowanie59' )
go
insert t values( 32, 'Testowanie36' )
go
insert t values( 33, 'Testowanie66' )
go
insert t values( 34, 'Testowanie87' )
go
insert t values( 35, 'Testowanie74' )
go
insert t values( 36, 'Testowanie12' )
go
insert t values( 37, 'Testowanie84' )
go
insert t values( 38, 'Testowanie15' )
go
insert t values( 39, 'Testowanie85' )
go
insert t values( 40, 'Testowanie69' )
go
insert t values( 41, 'Testowanie1' )
go
insert t values( 42, 'Testowanie67' )
go
insert t values( 43, 'Testowanie54' )
go
insert t values( 44, 'Testowanie67' )
go
insert t values( 45, 'Testowanie43' )
go
insert t values( 46, 'Testowanie79' )
go
insert t values( 47, 'Testowanie10' )
go
insert t values( 48, 'Testowanie17' )
go
insert t values( 49, 'Testowanie81' )
go
insert t values( 50, 'Testowanie14' )
go
insert t values( 51, 'Testowanie82' )
go
insert t values( 52, 'Testowanie91' )
go
insert t values( 53, 'Testowanie22' )
go
insert t values( 54, 'Testowanie89' )
go
insert t values( 55, 'Testowanie61' )
go
insert t values( 56, 'Testowanie41' )
go
insert t values( 57, 'Testowanie84' )
go
insert t values( 58, 'Testowanie77' )
go
insert t values( 59, 'Testowanie0' )
go
insert t values( 60, 'Testowanie31' )
go
insert t values( 61, 'Testowanie96' )
go
insert t values( 62, 'Testowanie60' )
go
insert t values( 63, 'Testowanie67' )
go
insert t values( 64, 'Testowanie94' )
go
insert t values( 65, 'Testowanie79' )
go
insert t values( 66, 'Testowanie73' )
go
insert t values( 67, 'Testowanie6' )
go
insert t values( 68, 'Testowanie64' )
go
insert t values( 69, 'Testowanie89' )
go
insert t values( 70, 'Testowanie23' )
go
insert t values( 71, 'Testowanie65' )
go
insert t values( 72, 'Testowanie22' )
go
insert t values( 73, 'Testowanie90' )
go
insert t values( 74, 'Testowanie20' )
go
insert t values( 75, 'Testowanie22' )
go
insert t values( 76, 'Testowanie65' )
go
insert t values( 77, 'Testowanie31' )
go
insert t values( 78, 'Testowanie64' )
go
insert t values( 79, 'Testowanie83' )
go
insert t values( 80, 'Testowanie12' )
go
insert t values( 81, 'Testowanie79' )
go
insert t values( 82, 'Testowanie97' )
go
insert t values( 83, 'Testowanie4' )
go
insert t values( 84, 'Testowanie33' )
go
insert t values( 85, 'Testowanie18' )
go
insert t values( 86, 'Testowanie97' )
go
insert t values( 87, 'Testowanie75' )
go
insert t values( 88, 'Testowanie3' )
go
insert t values( 89, 'Testowanie75' )
go
insert t values( 90, 'Testowanie7' )
go
insert t values( 91, 'Testowanie66' )
go
insert t values( 92, 'Testowanie3' )
go
insert t values( 93, 'Testowanie67' )
go
insert t values( 94, 'Testowanie65' )
go
insert t values( 95, 'Testowanie97' )
go
insert t values( 96, 'Testowanie79' )
go
insert t values( 97, 'Testowanie38' )
go
insert t values( 98, 'Testowanie35' )
go
insert t values( 99, 'Testowanie75' )
go
insert t values( 100, 'Testowanie59' )
go
insert t values( 101, 'Testowanie59' )
go
insert t values( 102, 'Testowanie40' )
go
insert t values( 103, 'Testowanie14' )
go
insert t values( 104, 'Testowanie81' )
go
insert t values( 105, 'Testowanie60' )
go
insert t values( 106, 'Testowanie36' )
go
insert t values( 107, 'Testowanie47' )
go
insert t values( 108, 'Testowanie92' )
go
insert t values( 109, 'Testowanie0' )
go
insert t values( 110, 'Testowanie62' )
go
insert t values( 111, 'Testowanie36' )
go
insert t values( 112, 'Testowanie11' )
go
insert t values( 113, 'Testowanie91' )
go
insert t values( 114, 'Testowanie72' )
go
insert t values( 115, 'Testowanie45' )
go
insert t values( 116, 'Testowanie10' )
go
insert t values( 117, 'Testowanie2' )
go
insert t values( 118, 'Testowanie52' )
go
insert t values( 119, 'Testowanie45' )
go
insert t values( 120, 'Testowanie77' )
go
insert t values( 121, 'Testowanie59' )
go
insert t values( 122, 'Testowanie11' )
go
insert t values( 123, 'Testowanie12' )
go
insert t values( 124, 'Testowanie59' )
go
insert t values( 125, 'Testowanie76' )
go
insert t values( 126, 'Testowanie9' )
go
insert t values( 127, 'Testowanie38' )
go
insert t values( 128, 'Testowanie46' )
go
insert t values( 129, 'Testowanie44' )
go
insert t values( 130, 'Testowanie13' )
go
insert t values( 131, 'Testowanie38' )
go
insert t values( 132, 'Testowanie35' )
go
insert t values( 133, 'Testowanie53' )
go
insert t values( 134, 'Testowanie52' )
go
insert t values( 135, 'Testowanie17' )
go
insert t values( 136, 'Testowanie46' )
go
insert t values( 137, 'Testowanie20' )
go
insert t values( 138, 'Testowanie64' )
go
insert t values( 139, 'Testowanie38' )
go
insert t values( 140, 'Testowanie52' )
go
insert t values( 141, 'Testowanie58' )
go
insert t values( 142, 'Testowanie6' )
go
insert t values( 143, 'Testowanie64' )
go
insert t values( 144, 'Testowanie49' )
go
insert t values( 145, 'Testowanie79' )
go
insert t values( 146, 'Testowanie41' )
go
insert t values( 147, 'Testowanie59' )
go
insert t values( 148, 'Testowanie81' )
go
insert t values( 149, 'Testowanie25' )
go
insert t values( 150, 'Testowanie4' )
go
insert t values( 151, 'Testowanie90' )
go
insert t values( 152, 'Testowanie84' )
go
insert t values( 153, 'Testowanie47' )
go
insert t values( 154, 'Testowanie2' )
go
insert t values( 155, 'Testowanie75' )
go
insert t values( 156, 'Testowanie23' )
go
insert t values( 157, 'Testowanie43' )
go
insert t values( 158, 'Testowanie13' )
go
insert t values( 159, 'Testowanie2' )
go
insert t values( 160, 'Testowanie19' )
go
insert t values( 161, 'Testowanie26' )
go
insert t values( 162, 'Testowanie40' )
go
insert t values( 163, 'Testowanie55' )
go
insert t values( 164, 'Testowanie12' )
go
insert t values( 165, 'Testowanie24' )
go
insert t values( 166, 'Testowanie72' )
go
insert t values( 167, 'Testowanie58' )
go
insert t values( 168, 'Testowanie44' )
go
insert t values( 169, 'Testowanie68' )
go
insert t values( 170, 'Testowanie28' )
go
insert t values( 171, 'Testowanie28' )
go
insert t values( 172, 'Testowanie26' )
go
insert t values( 173, 'Testowanie34' )
go
insert t values( 174, 'Testowanie24' )
go
insert t values( 175, 'Testowanie75' )
go
insert t values( 176, 'Testowanie45' )
go
insert t values( 177, 'Testowanie65' )
go
insert t values( 178, 'Testowanie67' )
go
insert t values( 179, 'Testowanie26' )
go
insert t values( 180, 'Testowanie90' )
go
insert t values( 181, 'Testowanie71' )
go
insert t values( 182, 'Testowanie48' )
go
insert t values( 183, 'Testowanie7' )
go
insert t values( 184, 'Testowanie19' )
go
insert t values( 185, 'Testowanie50' )
go
insert t values( 186, 'Testowanie82' )
go
insert t values( 187, 'Testowanie74' )
go
insert t values( 188, 'Testowanie25' )
go
insert t values( 189, 'Testowanie28' )
go
insert t values( 190, 'Testowanie76' )
go
insert t values( 191, 'Testowanie45' )
go
insert t values( 192, 'Testowanie86' )
go
insert t values( 193, 'Testowanie48' )
go
insert t values( 194, 'Testowanie0' )
go
insert t values( 195, 'Testowanie98' )
go
insert t values( 196, 'Testowanie4' )
go
insert t values( 197, 'Testowanie72' )
go
insert t values( 198, 'Testowanie56' )
go
insert t values( 199, 'Testowanie48' )
go
insert t values( 200, 'Testowanie72' )
go
insert t values( 201, 'Testowanie84' )
go
insert t values( 202, 'Testowanie9' )
go
insert t values( 203, 'Testowanie98' )
go
insert t values( 204, 'Testowanie51' )
go
insert t values( 205, 'Testowanie33' )
go
insert t values( 206, 'Testowanie73' )
go
insert t values( 207, 'Testowanie96' )
go
insert t values( 208, 'Testowanie99' )
go
insert t values( 209, 'Testowanie72' )
go
insert t values( 210, 'Testowanie55' )
go
insert t values( 211, 'Testowanie21' )
go
insert t values( 212, 'Testowanie44' )
go
insert t values( 213, 'Testowanie3' )
go
insert t values( 214, 'Testowanie60' )
go
insert t values( 215, 'Testowanie95' )
go
insert t values( 216, 'Testowanie86' )
go
insert t values( 217, 'Testowanie43' )
go
insert t values( 218, 'Testowanie1' )
go
insert t values( 219, 'Testowanie11' )
go
insert t values( 220, 'Testowanie3' )
go
insert t values( 221, 'Testowanie78' )
go
insert t values( 222, 'Testowanie56' )
go
insert t values( 223, 'Testowanie89' )
go
insert t values( 224, 'Testowanie58' )
go
insert t values( 225, 'Testowanie88' )
go
insert t values( 226, 'Testowanie88' )
go
insert t values( 227, 'Testowanie63' )
go
insert t values( 228, 'Testowanie92' )
go
insert t values( 229, 'Testowanie76' )
go
insert t values( 230, 'Testowanie43' )
go
insert t values( 231, 'Testowanie64' )
go
insert t values( 232, 'Testowanie93' )
go
insert t values( 233, 'Testowanie52' )
go
insert t values( 234, 'Testowanie62' )
go
insert t values( 235, 'Testowanie44' )
go
insert t values( 236, 'Testowanie86' )
go
insert t values( 237, 'Testowanie68' )
go
insert t values( 238, 'Testowanie72' )
go
insert t values( 239, 'Testowanie17' )
go
insert t values( 240, 'Testowanie40' )
go
insert t values( 241, 'Testowanie27' )
go
insert t values( 242, 'Testowanie70' )
go
insert t values( 243, 'Testowanie16' )
go
insert t values( 244, 'Testowanie31' )
go
insert t values( 245, 'Testowanie31' )
go
insert t values( 246, 'Testowanie43' )
go
insert t values( 247, 'Testowanie49' )
go
insert t values( 248, 'Testowanie6' )
go
insert t values( 249, 'Testowanie45' )
go
insert t values( 250, 'Testowanie60' )
go
insert t values( 251, 'Testowanie9' )
go
insert t values( 252, 'Testowanie55' )
go
insert t values( 253, 'Testowanie49' )
go
insert t values( 254, 'Testowanie98' )
go
insert t values( 255, 'Testowanie13' )
go
insert t values( 256, 'Testowanie37' )
go
insert t values( 257, 'Testowanie86' )
go
insert t values( 258, 'Testowanie8' )
go
insert t values( 259, 'Testowanie30' )
go
insert t values( 260, 'Testowanie95' )
go
insert t values( 261, 'Testowanie52' )
go
insert t values( 262, 'Testowanie26' )
go
insert t values( 263, 'Testowanie88' )
go
insert t values( 264, 'Testowanie36' )
go
insert t values( 265, 'Testowanie89' )
go
insert t values( 266, 'Testowanie32' )
go
insert t values( 267, 'Testowanie54' )
go
insert t values( 268, 'Testowanie89' )
go
insert t values( 269, 'Testowanie4' )
go
insert t values( 270, 'Testowanie71' )
go
insert t values( 271, 'Testowanie61' )
go
insert t values( 272, 'Testowanie64' )
go
insert t values( 273, 'Testowanie42' )
go
insert t values( 274, 'Testowanie78' )
go
insert t values( 275, 'Testowanie95' )
go
insert t values( 276, 'Testowanie5' )
go
insert t values( 277, 'Testowanie53' )
go
insert t values( 278, 'Testowanie76' )
go
insert t values( 279, 'Testowanie11' )
go
insert t values( 280, 'Testowanie98' )
go
insert t values( 281, 'Testowanie68' )
go
insert t values( 282, 'Testowanie52' )
go
insert t values( 283, 'Testowanie85' )
go
insert t values( 284, 'Testowanie17' )
go
insert t values( 285, 'Testowanie50' )
go
insert t values( 286, 'Testowanie31' )
go
insert t values( 287, 'Testowanie87' )
go
insert t values( 288, 'Testowanie69' )
go
insert t values( 289, 'Testowanie39' )
go
insert t values( 290, 'Testowanie49' )
go
insert t values( 291, 'Testowanie64' )
go
insert t values( 292, 'Testowanie23' )
go
insert t values( 293, 'Testowanie75' )
go
insert t values( 294, 'Testowanie52' )
go
insert t values( 295, 'Testowanie92' )
go
insert t values( 296, 'Testowanie96' )
go
insert t values( 297, 'Testowanie16' )
go
insert t values( 298, 'Testowanie46' )
go
insert t values( 299, 'Testowanie17' )
go
insert t values( 300, 'Testowanie52' )
go
insert t values( 301, 'Testowanie50' )
go
insert t values( 302, 'Testowanie79' )
go
insert t values( 303, 'Testowanie16' )
go
insert t values( 304, 'Testowanie24' )
go
insert t values( 305, 'Testowanie89' )
go
insert t values( 306, 'Testowanie43' )
go
insert t values( 307, 'Testowanie29' )
go
insert t values( 308, 'Testowanie42' )
go
insert t values( 309, 'Testowanie19' )
go
insert t values( 310, 'Testowanie72' )
go
insert t values( 311, 'Testowanie73' )
go
insert t values( 312, 'Testowanie88' )
go
insert t values( 313, 'Testowanie24' )
go
insert t values( 314, 'Testowanie90' )
go
insert t values( 315, 'Testowanie37' )
go
insert t values( 316, 'Testowanie6' )
go
insert t values( 317, 'Testowanie21' )
go
insert t values( 318, 'Testowanie56' )
go
insert t values( 319, 'Testowanie75' )
go
insert t values( 320, 'Testowanie93' )
go
insert t values( 321, 'Testowanie37' )
go
insert t values( 322, 'Testowanie71' )
go
insert t values( 323, 'Testowanie16' )
go
insert t values( 324, 'Testowanie45' )
go
insert t values( 325, 'Testowanie55' )
go
insert t values( 326, 'Testowanie8' )
go
insert t values( 327, 'Testowanie73' )
go
insert t values( 328, 'Testowanie71' )
go
insert t values( 329, 'Testowanie87' )
go
insert t values( 330, 'Testowanie91' )
go
insert t values( 331, 'Testowanie56' )
go
insert t values( 332, 'Testowanie37' )
go
insert t values( 333, 'Testowanie2' )
go
insert t values( 334, 'Testowanie72' )
go
insert t values( 335, 'Testowanie61' )
go
insert t values( 336, 'Testowanie91' )
go
insert t values( 337, 'Testowanie48' )
go
insert t values( 338, 'Testowanie90' )
go
insert t values( 339, 'Testowanie65' )
go
insert t values( 340, 'Testowanie67' )
go
insert t values( 341, 'Testowanie62' )
go
insert t values( 342, 'Testowanie70' )
go
insert t values( 343, 'Testowanie87' )
go
insert t values( 344, 'Testowanie18' )
go
insert t values( 345, 'Testowanie61' )
go
insert t values( 346, 'Testowanie57' )
go
insert t values( 347, 'Testowanie24' )
go
insert t values( 348, 'Testowanie82' )
go
insert t values( 349, 'Testowanie45' )
go
insert t values( 350, 'Testowanie32' )
go
insert t values( 351, 'Testowanie75' )
go
insert t values( 352, 'Testowanie15' )
go
insert t values( 353, 'Testowanie3' )
go
insert t values( 354, 'Testowanie24' )
go
insert t values( 355, 'Testowanie60' )
go
insert t values( 356, 'Testowanie91' )
go
insert t values( 357, 'Testowanie64' )
go
insert t values( 358, 'Testowanie65' )
go
insert t values( 359, 'Testowanie94' )
go
insert t values( 360, 'Testowanie51' )
go
insert t values( 361, 'Testowanie56' )
go
insert t values( 362, 'Testowanie50' )
go
insert t values( 363, 'Testowanie88' )
go
insert t values( 364, 'Testowanie58' )
go
insert t values( 365, 'Testowanie55' )
go
insert t values( 366, 'Testowanie49' )
go
insert t values( 367, 'Testowanie81' )
go
insert t values( 368, 'Testowanie3' )
go
insert t values( 369, 'Testowanie71' )
go
insert t values( 370, 'Testowanie79' )
go
insert t values( 371, 'Testowanie2' )
go
insert t values( 372, 'Testowanie65' )
go
insert t values( 373, 'Testowanie49' )
go
insert t values( 374, 'Testowanie22' )
go
insert t values( 375, 'Testowanie83' )
go
insert t values( 376, 'Testowanie42' )
go
insert t values( 377, 'Testowanie11' )
go
insert t values( 378, 'Testowanie40' )
go
insert t values( 379, 'Testowanie57' )
go
insert t values( 380, 'Testowanie56' )
go
insert t values( 381, 'Testowanie72' )
go
insert t values( 382, 'Testowanie32' )
go
insert t values( 383, 'Testowanie71' )
go
insert t values( 384, 'Testowanie7' )
go
insert t values( 385, 'Testowanie88' )
go
insert t values( 386, 'Testowanie63' )
go
insert t values( 387, 'Testowanie98' )
go
insert t values( 388, 'Testowanie53' )
go
insert t values( 389, 'Testowanie29' )
go
insert t values( 390, 'Testowanie93' )
go
insert t values( 391, 'Testowanie36' )
go
insert t values( 392, 'Testowanie17' )
go
insert t values( 393, 'Testowanie75' )
go
insert t values( 394, 'Testowanie25' )
go
insert t values( 395, 'Testowanie8' )
go
insert t values( 396, 'Testowanie30' )
go
insert t values( 397, 'Testowanie6' )
go
insert t values( 398, 'Testowanie89' )
go
insert t values( 399, 'Testowanie65' )
go
insert t values( 400, 'Testowanie10' )
go
insert t values( 401, 'Testowanie0' )
go
insert t values( 402, 'Testowanie68' )
go
insert t values( 403, 'Testowanie75' )
go
insert t values( 404, 'Testowanie82' )
go
insert t values( 405, 'Testowanie90' )
go
insert t values( 406, 'Testowanie91' )
go
insert t values( 407, 'Testowanie24' )
go
insert t values( 408, 'Testowanie1' )
go
insert t values( 409, 'Testowanie31' )
go
insert t values( 410, 'Testowanie81' )
go
insert t values( 411, 'Testowanie89' )
go
insert t values( 412, 'Testowanie35' )
go
insert t values( 413, 'Testowanie46' )
go
insert t values( 414, 'Testowanie93' )
go
insert t values( 415, 'Testowanie74' )
go
insert t values( 416, 'Testowanie66' )
go
insert t values( 417, 'Testowanie56' )
go
insert t values( 418, 'Testowanie73' )
go
insert t values( 419, 'Testowanie19' )
go
insert t values( 420, 'Testowanie85' )
go
insert t values( 421, 'Testowanie98' )
go
insert t values( 422, 'Testowanie56' )
go
insert t values( 423, 'Testowanie35' )
go
insert t values( 424, 'Testowanie5' )
go
insert t values( 425, 'Testowanie13' )
go
insert t values( 426, 'Testowanie43' )
go
insert t values( 427, 'Testowanie68' )
go
insert t values( 428, 'Testowanie51' )
go
insert t values( 429, 'Testowanie32' )
go
insert t values( 430, 'Testowanie33' )
go
insert t values( 431, 'Testowanie61' )
go
insert t values( 432, 'Testowanie65' )
go
insert t values( 433, 'Testowanie1' )
go
insert t values( 434, 'Testowanie69' )
go
insert t values( 435, 'Testowanie47' )
go
insert t values( 436, 'Testowanie23' )
go
insert t values( 437, 'Testowanie60' )
go
insert t values( 438, 'Testowanie3' )
go
insert t values( 439, 'Testowanie56' )
go
insert t values( 440, 'Testowanie23' )
go
insert t values( 441, 'Testowanie85' )
go
insert t values( 442, 'Testowanie78' )
go
insert t values( 443, 'Testowanie90' )
go
insert t values( 444, 'Testowanie63' )
go
insert t values( 445, 'Testowanie71' )
go
insert t values( 446, 'Testowanie64' )
go
insert t values( 447, 'Testowanie29' )
go
insert t values( 448, 'Testowanie59' )
go
insert t values( 449, 'Testowanie69' )
go
insert t values( 450, 'Testowanie81' )
go
insert t values( 451, 'Testowanie77' )
go
insert t values( 452, 'Testowanie67' )
go
insert t values( 453, 'Testowanie69' )
go
insert t values( 454, 'Testowanie12' )
go
insert t values( 455, 'Testowanie5' )
go
insert t values( 456, 'Testowanie14' )
go
insert t values( 457, 'Testowanie55' )
go
insert t values( 458, 'Testowanie73' )
go
insert t values( 459, 'Testowanie65' )
go
insert t values( 460, 'Testowanie19' )
go
insert t values( 461, 'Testowanie6' )
go
insert t values( 462, 'Testowanie59' )
go
insert t values( 463, 'Testowanie84' )
go
insert t values( 464, 'Testowanie40' )
go
insert t values( 465, 'Testowanie28' )
go
insert t values( 466, 'Testowanie31' )
go
insert t values( 467, 'Testowanie95' )
go
insert t values( 468, 'Testowanie20' )
go
insert t values( 469, 'Testowanie67' )
go
insert t values( 470, 'Testowanie84' )
go
insert t values( 471, 'Testowanie75' )
go
insert t values( 472, 'Testowanie84' )
go
insert t values( 473, 'Testowanie62' )
go
insert t values( 474, 'Testowanie65' )
go
insert t values( 475, 'Testowanie47' )
go
insert t values( 476, 'Testowanie65' )
go
insert t values( 477, 'Testowanie29' )
go
insert t values( 478, 'Testowanie8' )
go
insert t values( 479, 'Testowanie24' )
go
insert t values( 480, 'Testowanie99' )
go
insert t values( 481, 'Testowanie21' )
go
insert t values( 482, 'Testowanie1' )
go
insert t values( 483, 'Testowanie98' )
go
insert t values( 484, 'Testowanie90' )
go
insert t values( 485, 'Testowanie13' )
go
insert t values( 486, 'Testowanie3' )
go
insert t values( 487, 'Testowanie36' )
go
insert t values( 488, 'Testowanie0' )
go
insert t values( 489, 'Testowanie8' )
go
insert t values( 490, 'Testowanie2' )
go
insert t values( 491, 'Testowanie20' )
go
insert t values( 492, 'Testowanie15' )
go
insert t values( 493, 'Testowanie93' )
go
insert t values( 494, 'Testowanie4' )
go
insert t values( 495, 'Testowanie55' )
go
insert t values( 496, 'Testowanie53' )
go
insert t values( 497, 'Testowanie68' )
go
insert t values( 498, 'Testowanie82' )
go
insert t values( 499, 'Testowanie5' )
go
insert t values( 500, 'Testowanie35' )
go
INSERT INTO TimeTest VALUES('EndTime',GETDATE());
GO
DECLARE @StartTime DATETIME2, @EndTime DATETIME2
SELECT @StartTime=[Value] FROM TimeTest WHERE [Key]='StartTime';
SELECT @EndTime=[Value] FROM TimeTest WHERE [Key]='EndTime';
SELECT DATEDIFF(MS, @StartTime, @EndTime) Miliseconds
GO

